<?php
/**
 * Plugin Name: Voorro Vacatures
 * Plugin URI: https://voorro.nl
 * Description: Deze plugin stelt je in staat om vacatures toe te voegen
 * Version: 0.1
 * Author: Vincent Schuurman
 * Author URI: https://example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: voorro-jobs
 * Domain Path: /languages
 */


//include php files
require_once plugin_dir_path(__FILE__) . 'functions/custom-post-type.php';
require_once plugin_dir_path(__FILE__) . 'functions/api.php';


